export class TestConfig{
 
    appUrl="http://localhost/opencart/upload/"
    //appUrl="https://naveenautomationlabs.com/opencart"
    //appUrl="https://tutorialsninja.com/demo/"
    
  
    //valid login credentials
    email="pavanol@abc.com"
    password="test@123"

    //product details
    productName="MacBook"
    productQuantity="2"
    totalPrice="$1,204.00"
}